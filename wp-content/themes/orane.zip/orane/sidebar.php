					<!-- start sidebar -->
					<div class="col-md-4 sidebar">
						<?php 
							if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('orane_sidebar') ) :
						endif; 
						?>
					</div>
					<!-- ends sidebar -->